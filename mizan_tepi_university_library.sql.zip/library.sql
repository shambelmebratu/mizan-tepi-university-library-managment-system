--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `agriculture`
--

CREATE TABLE `agriculture` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agriculture`
--

INSERT INTO `agriculture` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`) VALUES
(1, '8976', 'basics of agriculture science', 'dr mohamed', '8th', '2009', '4323-224', '563908', 'wingin 11', 'canada', 'hf\r\n122334\r\n5432'),
(2, '9999', '321', '2121', '1st', '2000', '888-543', '13333', 'bright', 'germen', 'shambel\r\n1234\r\ntu899');

-- --------------------------------------------------------

--
-- Table structure for table `circulation_books`
--

CREATE TABLE `circulation_books` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `circulation_books`
--

INSERT INTO `circulation_books` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`, `quantity`) VALUES
(1, '56', 'history of great ethiopia', 'aaa', '5th', '1990', '78999', 'jkjjkjk', 'aaaster', 'ethiopia', 'uy\r\n9900\r\nmnjh', 5),
(2, '9383', 'my history', 'shambel', '1st', '2010', '8943', '98438934', 'shambel', 'mizan teferi', '849938]\r\njk\r\n39990', 2),
(3, '983493', 'accounting', 'sm', '2nd', '2010', '9348', '499439349', 'mega', 'aa', '849\r\nksljdslk\r\nls', 2),
(14, '4444321', 'php', 'shambel', '5th', '2015', '114432', '89756', 'mizan', 'AA - ethiopia ', '48\r\nht\r\n8948984', 4),
(15, '58', 'love history', 'sheksper', '2nd', '2018', '8938-dl', '93094493', 'ethio-family', 'ethiopia aa', 'hd\r\n89309\r\nlskk', 3);

-- --------------------------------------------------------

--
-- Table structure for table `fb`
--

CREATE TABLE `fb` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fb`
--

INSERT INTO `fb` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`) VALUES
(1, '123', 'eco', 'ma', '', '', '', 'ff', '', '', 'HF\r\n1234\r\nFH\r\n321'),
(2, '123', 'fundamental of economics and business science for beginners and advanced', 'william , j.bastos, liana', '7th', '2010', 'i-58939893-lsksls', '39393993-39933939', 'the last book', 'newyork', 'HD\r\n28-70\r\n.B3\r\n2000'),
(3, '6666666777777', 'fundamental', 'wilian', '', '', '', '', '', '', 'HF\r\n5549\r\n.HB \r\n2000'),
(4, '4444321', 'manegment', 'shambel', '5th', '2018', '123we34', '44531', 'mizan', 'ethiopia', 'YU\r\n903039904\r\nBN\r\n940394');

-- --------------------------------------------------------

--
-- Table structure for table `health`
--

CREATE TABLE `health` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `health`
--

INSERT INTO `health` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`) VALUES
(1, '000000012', 'anatomy', 'guangulize', '7th', '2015', '23421', '123', 'wer', 'london', 'hd\r\n543212\r\n.gh\r\n4321234');

-- --------------------------------------------------------

--
-- Table structure for table `law`
--

CREATE TABLE `law` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `law`
--

INSERT INTO `law` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`) VALUES
(1, '7593030', 'consti', 'shamb', '6th', '2010', '', '', '', '', 'law\r\n9303940\r\nty\r\n0290');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `user_name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`user_name`, `phone`, `email`, `password`) VALUES
('shambel mebratu', '0921215699', 'sm@gmail.com', '12'),
('admin', '0948950157', 'admin@mtu.com', 'mtu12');

-- --------------------------------------------------------

--
-- Table structure for table `social_and_humanity`
--

CREATE TABLE `social_and_humanity` (
  `roll_no` int(11) NOT NULL,
  `acc_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `year_of_publication` varchar(100) NOT NULL,
  `ISBN` varchar(100) NOT NULL,
  `call_no` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `place_of_publication` varchar(100) NOT NULL,
  `shelfmark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_and_humanity`
--

INSERT INTO `social_and_humanity` (`roll_no`, `acc_no`, `book_title`, `author`, `edition`, `year_of_publication`, `ISBN`, `call_no`, `publisher_name`, `place_of_publication`, `shelfmark`) VALUES
(1, '234', 'appliad mathimatics', 'j.stewart', '5th', '2011', '12345', '895432', 'world top enterprise', 'London', 'LO\r\n489309\r\nSM\r\n902302'),
(6, '4444321', 'ethiopian history', 'lema', '5th', '1986', '114432', '89756', 'selama', 'AA - ethiopia ', 'AA\r\n553039\r\nTY\r\n3089'),
(7, '9034039490', 'chemistry', 'chang', '2nd', '2014', '9032984', '894900309', 'black ', 'rome', 'PP\r\n894984893\r\nJ\r\n89032039');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `roll_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `time_issued` time NOT NULL,
  `return_time` time NOT NULL,
  `book_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`roll_no`, `date`, `user_id`, `time_issued`, `return_time`, `book_title`) VALUES
(10, '2018-08-04', '776655', '05:34:37', '07:34:48', 'php'),
(15, '2018-08-04', '1', '06:16:42', '08:16:53', 'php'),
(16, '2018-08-05', '1222', '03:36:16', '04:36:33', 'accounting'),
(17, '2018-08-10', '105', '03:53:31', '04:53:37', 'my history'),
(18, '2018-08-10', '1023', '04:05:07', '07:05:16', 'love history');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agriculture`
--
ALTER TABLE `agriculture`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `circulation_books`
--
ALTER TABLE `circulation_books`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `fb`
--
ALTER TABLE `fb`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `health`
--
ALTER TABLE `health`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `law`
--
ALTER TABLE `law`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `social_and_humanity`
--
ALTER TABLE `social_and_humanity`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`roll_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agriculture`
--
ALTER TABLE `agriculture`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `circulation_books`
--
ALTER TABLE `circulation_books`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `fb`
--
ALTER TABLE `fb`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `health`
--
ALTER TABLE `health`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `law`
--
ALTER TABLE `law`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `social_and_humanity`
--
ALTER TABLE `social_and_humanity`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
